"""mlops-bydesign-quickstart: Quickly create ML experiments"""

__version__ = "0.1.0"

from .core import create_experiment

__all__ = ["create_experiment"]